<?php
class All{

    // Connection instance
    private $connection;

    // table name
    private $table_name = "All";

    // table columns
    public $Categorie_ID;
    public $Categorie_naam;
    public $firstname;
    public $password;

    public $Lener_ID;
    public $Lener_naam;
    public $Lener_mobiel;
    public $Lener_email;
    public $Lener_afd;

    public $Object_ID;
    public $Object_naam;
    public $Object_merk;
    public $Object_type;
    public $Object_status;
    public $Object_img;
    public $Object_description;
    
    public $Uitleen_ID;
    public $Uitleendatum;
    public $Inleverdatum;
    

    public function __construct($connection){
        $this->connection = $connection;
    }

    //R
    public function read_all(){
        $query = "SELECT uitleen.Inleverdatum, lener.Lener_naam, object.Object_naam, object.Object_img FROM ((uitleen INNER JOIN lener ON uitleen.Lener_ID = Lener.Lener_ID) INNER JOIN object ON uitleen.Object_ID = object.Object_ID)";

        $stmt = $this->connection->prepare($query);

        $stmt->execute();

        return $stmt;
    } 
}