<?php
class All{

    // Connection instance
    private $connection;

    // table name
    private $table_name = "All";

    // table columns
    public $Categorie_ID;
    public $Categorie_naam;
    public $firstname;
    public $password;

    public $Lener_ID;
    public $Lener_naam;
    public $Lener_mobiel;
    public $Lener_email;
    public $Lener_afd;

    public $Object_ID;
    public $Object_naam;
    public $Object_merk;
    public $Object_type;
    public $Object_status;
    public $Object_img;

    public $Uitleen_ID;
    public $Uitleendatum;
    public $Inleverdatum;
    

    public function __construct($connection){
        $this->connection = $connection;
    }

    //C
    public function create(){
        $query ="INSERT INTO categorie (Categorie_naam) values(p.Categorie_naam)";

        $stmt = $this->connection->prepare($query);

        $stmt->execute();

        return $stmt;
    }
    //R
    public function read_categorie(){
        $query = "SELECT * from categorie";

        $stmt = $this->connection->prepare($query);

        $stmt->execute();

        return $stmt;
    } 
    public function read_lener(){
        $query = "SELECT * from lener";

        $stmt = $this->connection->prepare($query);

        $stmt->execute();

        return $stmt;
    }
    public function read_object(){
        $query = "SELECT * from object";

        $stmt = $this->connection->prepare($query);

        $stmt->execute();

        return $stmt;
    }
    public function read_uitleen(){
        $query = "SELECT * from uitleen";

        $stmt = $this->connection->prepare($query);

        $stmt->execute();

        return $stmt;
    }
    public function delete(){
        $query = "DELETE FROM categorie WHERE Categorie_ID= p.Categorie_ID";

        $stmt = $this->connection->prepare($query);

        $stmt->execute();

        return $stmt;
    }
}