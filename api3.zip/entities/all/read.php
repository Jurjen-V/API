<?php
header("Content-Type: application/json; charset=UTF-8");

include_once '../../Config/database.php';
include_once '../../entities/all.php';

$dbclass = new DBClass();
$connection = $dbclass->getConnection();

$All = new All($connection);

$stmt = $All->read_categorie();
$count = $stmt->rowCount();

if($count > 0){


    $Categorie = array();
    $Categorie["Categorie"] = array();
    $Categorie["count"] = $count;

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){

        extract($row);

        $p  = array(
              "Categorie_ID" => $Categorie_ID,
              "Categorie_naam" => $Categorie_naam,
        );
 
        array_push($Categorie["Categorie"], $p);
    }

    echo json_encode($Categorie);
}

else {

    echo json_encode(
        array("Categorie" => array(), "count" => 0)
    );
}

$stmt = $All->read_lener();
$count = $stmt->rowCount();

if($count > 0){
  $Lener = array();
  $Lener["lener"] = array();
  $Lener["count"] = $count;

  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    extract($row);

    $p  = array(
      "Lener_ID" => $Lener_ID,
      "Lener_naam" => $Lener_naam,
      "Lener_mobiel" => $Lener_mobiel,
      "Lener_email" => $Lener_email,
      "Lener_afd" => $Lener_afd,
    );
    array_push($Lener["lener"], $p);
  }

  echo json_encode($Lener);
}
else {
  echo json_encode(
    
    array("Lener" => array(), "count" => 0)
  );
}

$stmt = $All->read_object();
$count = $stmt->rowCount();

if($count > 0){
  $Object = array();
  $Object["Object"] = array();
  $Object["count"] = $count;

  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    extract($row);

    $p  = array(
      "Object_ID" => $Object_ID,
      "Object_naam" => $Object_naam,
      "Object_merk" => $Object_merk,
      "Object_type" => $Object_type,
      "Object_status" => $Object_status,
      "Categorie_ID" => $Categorie_ID,
      "Object_img" => $Object_img,
      "Object_description" => $Object_description
    );
    array_push($Object["Object"], $p);
  }

  echo json_encode($Object);
}
else {
  echo json_encode(
    array("Object" => array(), "count" => 0)
  );
}

$stmt = $All->read_uitleen();
$count = $stmt->rowCount();

if($count > 0){
  $Uitleen = array();
  $Uitleen["uitleen"] = array();
  $Uitleen["count"] = $count;

  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    extract($row);

    $p  = array(
      "Uitleen_ID" => $Uitleen_ID,
      "Lener_ID" => $Lener_ID,
      "Object_ID" => $Object_ID,
      "Uitleendatum" => $Uitleendatum,
      "Inleverdatum" => $Inleverdatum,
    );
    array_push($Uitleen["uitleen"], $p);
  }

  echo json_encode($Uitleen);
}
else {
  echo json_encode(
    array(Uitleen => array(), "count" => 0)
  );
}