<?php
class Objects{

    // Connection instance
    private $connection;

    // table name
    private $table_name = "Objects";

    // table columns
    public $Categorie_ID;
    public $Categorie_naam;
    public $Object_ID;
    public $Object_naam;
    public $Object_merk;
    public $Object_type;
    public $Object_status;
    
    public function __construct($connection){
        $this->connection = $connection;
    }

    public function read(){
        $query = "SELECT * from object";

        $stmt = $this->connection->prepare($query);

        $stmt->execute();

        return $stmt;
    }
    public function delete(){
        $query = "DELETE FROM categorie WHERE Categorie_ID= p.Categorie_ID";

        $stmt = $this->connection->prepare($query);

        $stmt->execute();

        return $stmt;
    }
}