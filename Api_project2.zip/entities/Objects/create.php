<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';

include_once '../../entities/objects.php';
include_once '../../entities/security.php';

ApiKey();
if($_GET['ApiKey'] == $ApiKey){
	$dbclass = new DBClass();
	$connection = $dbclass->getConnection();

	$categories = new categories($connection);

	$data = json_decode(file_get_contents("php://input"));

	$categories->Object_naam = $data->Object_naam;

	if($categories->create()){
	    echo '{';
	        echo '"message": "categories was created."';
	    echo '}';
	}
	else{
	    echo '{';
	        echo '"message": "Unable to create categories."';
	    echo '}';
	}
}