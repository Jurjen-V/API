<?php
class Uitleen{

    // Connection instance
    private $connection;

    // table name
    private $table_name = "Uitleen";

    // table columns
    public $Uitleen_ID;
    public $Lener_ID;
    public $Object_ID;
    public $Uitleendatum;
    public $Inleverdatum;
    
    public function __construct($connection){
        $this->connection = $connection;
    }

    public function read(){
        $query = "SELECT * from uitleen";

        $stmt = $this->connection->prepare($query);

        $stmt->execute();

        return $stmt;
    }
    // C
    public function create(){
        $query ="INSERT INTO Uitleen (Uitleen_ID, Lener_ID, Object_ID, Uitleendatum, Inleverdatum) values(p.Uitleen_ID, p.Lener_ID, p.Object_ID, p.Uitleendatum, p.Inleverdatum)";

        $stmt = $this->connection->prepare($query);

        $stmt->execute();

        return $stmt;
    }
    public function delete(string $Uitleen_ID) {
        $query = "DELETE FROM uitleen WHERE Uitleen_ID = ?";
        $stmt = $this->connection->prepare($query);
        // Pass an element from $p to the execute function to replace the ? placeholder
        $stmt->execute([
            $Object_ID
        ]);
        // return $stmt; // there is nothing to return from delete action
    }
        //U
    public function update(){
        $query ="UPDATE uitleen SET Uitleen_naam = p.Uitleen_naam, Uitleen_merk = p.Uitleen_merk, Uitleen_type = p.Uitleen_type, Uitleen_status = p.Uitleen_status, Object_ID = p.Object_ID, Uitleen_img = p.Uitleen_img WHERE Uitleen_ID = p.Uitleen_ID";
        $stmt = $this->connection->prepare($query);

        $stmt->execute();

        return $stmt;
    }
}