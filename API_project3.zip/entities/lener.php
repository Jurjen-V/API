<?php
class Objects{

    // Connection instance
    private $connection;

    // table name
    private $table_name = "Objects";

    // table columns
    public $Lener_ID;
    public $Lener_naam;
    public $Lener_mobiel;
    public $Lener_email;
    public $Lener_afd;

    public function __construct($connection){
        $this->connection = $connection;
    }

    public function read(){
        $query = "SELECT * from lener";

        $stmt = $this->connection->prepare($query);

]'= '
        $stmt->execute();

        return $stmt;
    }
    //C
//     public function create(){
//         $query ="INSERT INTO lener (Object_naam, Object_merk, Object_type, Object_status, Categorie_ID, Object_img) values(p.Object_naam, p.Object_merk, p.Object_type, p.Object_status, p.Categorie_ID, p.Object_img)";

//         $stmt = $this->connection->prepare($query);

//         $stmt->execute();

//         return $stmt;
//     }
//     public function delete(string $Object_ID) {
//         $query = "DELETE FROM lener WHERE Lener_ID = ?";
//         $stmt = $this->connection->prepare($query);
//         // Pass an element from $p to the execute function to replace the ? placeholder
//         $stmt->execute([
//             $Categorie_ID
//         ]);
//         // return $stmt; // there is nothing to return from delete action
//     }
//         //U
//     public function update(){
//         $query ="UPDATE lener SET Object_naam = p.Object_naam, Object_merk = p.Object_merk, Object_type = p.Object_type, Object_status = p.Object_status, Categorie_ID = p.Categorie_ID, Object_img = p.Object_img WHERE Object_ID = p.Object_ID";
//         $stmt = $this->connection->prepare($query);

//         $stmt->execute();

//         return $stmt;
//     }
}